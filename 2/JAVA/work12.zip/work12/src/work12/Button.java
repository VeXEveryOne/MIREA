package work12;

public interface Button {
    void draw();
}
