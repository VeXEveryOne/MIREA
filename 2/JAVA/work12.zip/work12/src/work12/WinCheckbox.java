package work12;

public class WinCheckbox implements Checkbox {
    @Override
    public void draw() {
        System.out.println("Drawing a Windows checkbox.");
    }
}
