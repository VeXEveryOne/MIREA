package work12;

public interface GUIFactory {
    Button createButton();
    Checkbox createCheckbox();
}
