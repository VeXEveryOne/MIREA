public interface Number {
    void print();  // Метод для печати числа
}