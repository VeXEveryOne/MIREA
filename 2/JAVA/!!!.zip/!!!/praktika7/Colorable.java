package praktika7;
public interface Colorable {
    void howToColor();
}
