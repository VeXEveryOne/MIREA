package praktika7;

public interface Comparable {
    public GeometricObject max(GeometricObject first, GeometricObject second);
}
