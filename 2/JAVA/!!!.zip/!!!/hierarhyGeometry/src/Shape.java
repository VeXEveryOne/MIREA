public interface Shape {
    double area();    // Метод для вычисления площади
    double perimeter();  // Метод для вычисления периметра
    void print();      // Метод для печати информации о фигуре
}
