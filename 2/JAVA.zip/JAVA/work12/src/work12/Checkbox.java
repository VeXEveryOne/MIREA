package work12;

public interface Checkbox {
    void draw();
}
