package work12;

public class WinButton implements Button {
    @Override
    public void draw() {
        System.out.println("Drawing a Windows button.");
    }
}