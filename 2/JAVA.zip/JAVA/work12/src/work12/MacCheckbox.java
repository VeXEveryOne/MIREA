package work12;

public class MacCheckbox implements Checkbox {
    @Override
    public void draw() {
        System.out.println("Drawing a MacOS checkbox.");
    }
}
