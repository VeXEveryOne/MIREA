package work12;

public class MacButton implements Button {
    @Override
    public void draw() {
        System.out.println("Drawing a MacOS button.");
    }
}
