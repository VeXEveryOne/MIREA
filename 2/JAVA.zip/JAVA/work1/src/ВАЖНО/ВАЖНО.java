package ВАЖНО;

import java.lang.Thread;

public class ВАЖНО {
    public static void main(String[] args) throws InterruptedException {
        for (int i = 10; i > 0; i--) {
            System.out.println(i);
            Thread.sleep(1000);
        }
        System.out.println("Поехали буддыыыыыыыыыыыыыыыыыы");
        Thread.sleep(1000);
        while (true){
            System.out.print("Соси ");
        }
    }
}
