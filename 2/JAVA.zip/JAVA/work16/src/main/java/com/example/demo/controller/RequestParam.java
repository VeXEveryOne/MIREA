package main.java.com.example.demo.controller;

public @interface RequestParam {
}
