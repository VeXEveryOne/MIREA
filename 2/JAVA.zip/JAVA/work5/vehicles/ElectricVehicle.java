package vehicles;

public interface ElectricVehicle {
    public int getBatteryCapacity();
    public void setBatteryCapacity(int batteryCapacity);
}
