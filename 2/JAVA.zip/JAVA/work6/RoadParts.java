package work6;

public interface RoadParts {
    final String terrain = "track_racing";
    int getTyreWidth();
    void setTyreWidth(int newValue);
    int getPostHeight();
    void setPostHeight(int newValue);
}
